<template>
  <div>
    <el-button type="primary">按钮</el-button>
    <el-button type="danger">按钮</el-button>
  </div>
</template>

<script>
export default {
  data () {
    return {
    }
  },
  methods: {}
}
</script>

<style scoped lang='scss'>
</style>
