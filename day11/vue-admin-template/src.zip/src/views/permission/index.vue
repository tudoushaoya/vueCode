<template>
  <div class="container">
    <div class="app-container">
      权限管理
    </div>
  </div>
</template>
<script>
export default {
  name: 'Permission'
}
</script>
