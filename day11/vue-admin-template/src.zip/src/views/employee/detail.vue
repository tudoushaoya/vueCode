<template>
  <div>
    <el-form ref="detailListRef" style="width: 300px; margin-top: 20px" label-width="80px" :model="detailList" :rules="rules">
      <el-form-item label="姓名" prop="username">
        <el-input v-model="detailList.username" size="mini" />
      </el-form-item>
      <el-form-item label="工号" prop="workNumber">
        <el-input v-model="detailList.workNumber" size="mini" disabled />
      </el-form-item>
      <el-form-item label="手机" prop="mobile">
        <el-input v-model="detailList.mobile" size="mini" :disabled="isEdit" />
      </el-form-item>
      <el-form-item label="部门" prop="departmentName">
        <!-- <el-input v-model="detailList.departmentName" size="mini" /> -->
        <el-cascader v-model="detailList.departmentName" :options="departments" :props="{label:'name',value:'id'}" />
      </el-form-item>
      <el-form-item label="聘用形式" prop="formOfEmployment">
        <el-select v-model="detailList.formOfEmployment">
          <el-option label="正式" :value="1" />
          <el-option label="非正式" :value="2" />
        </el-select>
      </el-form-item>
      <el-form-item label="入职时间" prop="timeOfEntry">
        <el-date-picker v-model="detailList.timeOfEntry" type="date" clearable placeholder="选择日期" />
      </el-form-item>
      <el-form-item label="转正时间" prop="correctionTime">
        <el-date-picker v-model="detailList.correctionTime" type="date" clearable placeholder="选择日期" />
      </el-form-item>
      <el-form-item label="头像" prop="staffPhoto">
        <el-input size="mini" />
      </el-form-item>
      <el-form-item label="姓名">
        <el-button size="mini" type="primary" @click="update">更新</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import { getDepartments } from '@/api/department'
import { transListToTree, parseTime } from '@/utils/index.js'
import { getPersonalDetail, addEmployee, updateEmployee } from '@/api/user'
export default {
  name: 'EmployeeDetail',
  data() {
    return {
      detailList: {},
      rules: {
        username: [{ required: true, message: '请输入姓名', trigger: 'blur' }, {
          min: 1, max: 4, message: '姓名为1-4位'
        }],
        mobile: [{ required: true, message: '请输入手机号', trigger: 'blur' }, {
        //   pattern 正则表达式
          pattern: /^1[3-9]\d{9}$/,
          message: '手机号格式不正确',
          trigger: 'blur'
        }],
        formOfEmployment: [{ required: true, message: '请选择聘用形式', trigger: 'blur' }],
        departmentId: [{ required: true, message: '请选择部门', trigger: 'blur' }],
        timeOfEntry: [{ required: true, message: '请选择入职时间', trigger: 'blur' }],
        correctionTime: [{ required: true, message: '请选择转正时间', trigger: 'blur' }, {
          validator: (rule, value, callback) => {
            if (this.detailList.timeOfEntry) {
              if (new Date(this.detailList.timeOfEntry) > new Date(value)) {
                callback(new Error('转正时间不能小于入职时间'))
                return
              }
            }
            callback()
          }
        }]
      },
      departments: []
    }
  },
  computed: {
    isEdit() {
      return !!this.$route.params.id
    }
  },
  async created() {
    await this.getDetail()
    await this.getDepartments()
  },
  methods: {
    async getDetail() {
      if (!this.$route.params.id) return
      const res = await getPersonalDetail(this.$route.params.id)
      this.detailList = res
      console.log(this.detailList)
    },
    async getDepartments() {
      const res = await getDepartments()
      this.departments = transListToTree(res, 0)
    },
    async update() {
      const obj = { ...this.detailList }
      obj.departmentId = obj.departmentName.slice(-1)[0]
      obj.timeOfEntry = parseTime(obj.timeOfEntry, '{y}-{m}-{d}')
      if (this.isEdit) {
        await updateEmployee(obj)
        this.$message.success('更新成功')
        // 清空表单
        // this.$refs.detailListRef.resetFields()
      } else {
        await addEmployee(obj)
        this.$message.success('添加成功')
        // 清空表单
        this.$refs.detailListRef.resetFields()
      }
    }
  }
}
</script>

<style scoped lang='scss'></style>
