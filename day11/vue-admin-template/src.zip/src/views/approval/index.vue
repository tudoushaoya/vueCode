<template>
  <div class="container">
    <div class="app-container">
      审批
    </div>
  </div>
</template>
<script>
export default {
  name: 'Approvals'
}
</script>
