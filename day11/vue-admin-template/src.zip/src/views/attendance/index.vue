<template>
  <div class="container">
    <div class="app-container">
      考勤
    </div>
  </div>
</template>
<script>
export default {
  name: 'Attendance'
}
</script>
