<template>
  <div class="container">
    <div class="app-container">
      社保管理
    </div>
  </div>
</template>
<script>
export default {
  name: 'Social'
}
</script>
