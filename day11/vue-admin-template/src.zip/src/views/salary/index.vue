<template>
  <div class="container">
    <div class="app-container">
      工资管理
    </div>
  </div>
</template>
<script>
export default {
  name: 'Salary'
}
</script>
